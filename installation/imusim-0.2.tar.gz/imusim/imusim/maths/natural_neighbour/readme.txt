The code in this directory is taken from version 1 of the Natural Neighbour
Interpolation implementation by Ross Hemsley, available from:

http://code.google.com/p/interpolate3d/

where it is published under the GNU General Public License, version 3.
